class 10th result 
class 12th result
poltecnic admission 
iti college admission
